./mvnw clean install ./mvnw spring-boot:run

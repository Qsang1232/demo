package com.example.demo.model;

public enum AppointmentStatus {
    PENDING, CONFIRMED, COMPLETED, CANCELED
}
package com.example.demo.model;

public enum Role {
    ADMIN, EMPLOYEE, CUSTOMER
}
package com.example.demo.controller;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Car;
import com.example.demo.repository.CarRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/cars")
@RequiredArgsConstructor
public class CarController {

    private final CarRepository carRepository;

    // 1. API CÔNG KHAI: Xem tất cả xe (GET)
    @GetMapping
    public ResponseEntity<List<Car>> getAllCars() {
        return ResponseEntity.ok(carRepository.findAll());
    }

    // 2. API BẢO VỆ: Thêm xe mới (POST) - Chỉ ADMIN & EMPLOYEE
    @PostMapping
    public ResponseEntity<String> addCar(@RequestBody Car car) {
        carRepository.save(car);
        return ResponseEntity.status(HttpStatus.CREATED).body("Xe " + car.getName() + " đã được thêm thành công.");
    }

    // 3. API BẢO VỆ: Sửa thông tin xe (PUT /{id}) - Chỉ ADMIN & EMPLOYEE
    @PutMapping("/{id}")
    public ResponseEntity<String> updateCar(@PathVariable Long id, @RequestBody Car carDetails) {
        Car car = carRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Không tìm thấy xe với ID: " + id)); // <<< Sửa lỗi ở
                                                                                                      // đây

        // Cập nhật thông tin (Chỉ là ví dụ cơ bản)
        car.setName(carDetails.getName());
        car.setPrice(carDetails.getPrice());
        car.setDescription(carDetails.getDescription());
        carRepository.save(car);

        return ResponseEntity.ok("Xe với ID " + id + " đã được cập nhật.");
    }

    // 4. API BẢO VỆ: Xóa xe (DELETE /{id}) - Chỉ ADMIN & EMPLOYEE
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCar(@PathVariable Long id) {
        if (!carRepository.existsById(id)) {
            throw new RuntimeException("Không tìm thấy xe với ID: " + id);
        }
        carRepository.deleteById(id);
        return ResponseEntity.ok("Xe với ID " + id + " đã được xóa thành công.");
    }
}
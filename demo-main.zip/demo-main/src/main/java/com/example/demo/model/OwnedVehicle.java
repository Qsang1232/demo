package com.example.demo.model;

import lombok.Data;
import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Data
public class OwnedVehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- Thông tin định danh xe ---

    // Số Khung (Ví dụ: VIN)
    @Column(unique = true, nullable = false)
    private String chassisNumber;

    // Số Máy
    private String engineNumber;

    // Biển số xe (ID BẢNG)
    private String licensePlate;

    private String color; // Màu xe

    // --- Mối quan hệ với Chủ sở hữu (Khách hàng) ---
    // ID CỦA KHÁCH HÀNG
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "customer_id", nullable = false)
    private User customer;

    // --- Mối quan hệ với Mẫu xe (Car Model) ---
    // ID MẪU XE (ví dụ: Toyota Camry, BMW X5)
    // Giả sử Car Entity lưu trữ thông tin mẫu xe
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "car_model_id")
    private Car carModel;

    // --- Thông tin Bảo dưỡng/Bảo hành gần nhất ---

    // Ngày Tháng Đã Bảo Hành
    private LocalDate lastWarrantyDate;

    // Ngày Tháng Đã Bảo Dưỡng
    private LocalDate lastMaintenanceDate;

    // Bạn có thể mở rộng bằng cách thêm một Collection<MaintenanceHistory> nếu cần
    // lịch sử chi tiết
}
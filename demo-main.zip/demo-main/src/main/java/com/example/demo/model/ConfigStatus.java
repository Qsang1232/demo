package com.example.demo.model;

public enum ConfigStatus {
    PENDING_APPOINTMENT,
    BOOKED,
    COMPLETED
}
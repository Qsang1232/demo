package com.example.demo.model; // Dùng package bạn đã cung cấp

import lombok.Data;
import jakarta.persistence.*; // Đã chuyển sang Jakarta
import java.time.LocalDateTime;

@Entity
@Data
public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- Mối quan hệ ---

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user; // Khách hàng đặt lịch

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "config_id")
    private CarConfiguration carConfiguration; // Cấu hình xe đã chọn (Giỏ hàng)

    // --- Thông tin Lịch hẹn ---

    private LocalDateTime appointmentTime; // Thời gian đặt lịch

    @Enumerated(EnumType.STRING)
    private AppointmentType type; // Loại dịch vụ (MAINTENANCE, REPAIR, etc.)

    @Enumerated(EnumType.STRING)
    private AppointmentStatus status = AppointmentStatus.PENDING; // Trạng thái lịch hẹn

    private String notes; // Ghi chú của khách hàng (Được đặt ở cuối)
}
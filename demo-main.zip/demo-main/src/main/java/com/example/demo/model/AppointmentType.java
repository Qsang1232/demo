package com.example.demo.model;

public enum AppointmentType {
    MAINTENANCE, REPAIR, PURCHASE_CONSULTATION
}